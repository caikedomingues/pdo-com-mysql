



<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale 1.0"> 
        <meta http-equiv="X-UA Compatible" content="ie-edge">
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>


    <body>
        <header>
            <h1>Banco de dados com PDO</h1>
        </header>

            <main>
                 <!--Menu de opções do sistema-->
                <ul>
                    <li><a href="Apagar.php">Apagar dados</a></li>
                    <li><a href="Atualizar.php">Atualizar dados</a></li>
                    <li><a href="index.html">Inicio</a></li>
                    <li><a href="Selecionar.php">Pesquisar dados</a></li>
                </ul>
            </main>

        <section>

            <?php
            
                 /*Captura dos valores passado pelo o usuário */

                $tipo = $_GET['tipo'] ?? "nenhum"; //valor padrão caso o usuário não informe nenhum valor

                $modelo = $_GET['modelo']?? "nenhum"; //valor padrão caso o usuário não informe nenhum valor

                $placa = $_GET['placa']?? "nenhuma";//valor padrão caso o usuário não informe nenhum valor
            
            
            ?>

             <!--Criação do formulário-->
            <!--O formulário ira fazer referencia a variavel SERVER, que ira mandar as informações para as variáveis em php.O metodo será get, pois queremos pegar a informação-->
            <form action="<?php $_SERVER=['PHP_SELF']?>" method="get">

              <!--Legenda do  formulário-->
            <label for="tipo">Tipo:</label>

             <!--campo para inserção de dados: não possuem autocomplete e não podem ser vázios-->
            <input type="text" name="tipo" id="idtipo" autocomplete="off" required>

            <!--Legenda do  formulário-->
            <label for="modelo">Modelo:</label>

             <!--campo para inserção de dados: não possuem autocomplete e não podem ser vázios-->
            <input type="text" name="modelo" id="idmodelo" autocomplete="off" required>

             <!--Legenda do  formulário-->
            <label for="placa">Placa (apenas 4 digitos):</label>

             <!--campo para inserção de dados: não possuem autocomplete e não podem ser vázios-->
            <input type="text"  name="placa" id="idplaca" autocomplete="off" required>

               <!--Criação do botão de inserção  de dados-->
            <input type="submit" value="enviar informações">


        
            </form>
        </section>
        <section>
            <?php
            
             /*Inclusão do arquivo que contem os metodos para manipular o banco de dados */
            include 'BancoDeDados.php';

            /*Instanciação do banco de dados */
            $banco = new BancoDeDados();

            /*chamada do Metodo que ira receber como parametro os valores que serão inseridos no banco de dados*/
            echo $banco->inserir($tipo, $modelo, $placa);

            /*Mensagem que indica o ultimo cadastro realizado no momento */
            echo "<p>Dados cadastrados até o momento</p>";

            echo "<p> Tipo: $tipo</p>";

            echo "<p> Modelo $modelo</p>";

            echo "<p> Placa: $placa</p>";


       
            
            ?>
        </section>
    </body>
</html>

