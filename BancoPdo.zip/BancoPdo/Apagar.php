


<!DOCTYPE html>
<html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale 1.0">
        <meta http-equiv="X-UA Comptible" content="IE-edge">
        <link rel="stylesheet" href="estilo/estilo.css">
    </head>


    <body>

        <header>
            <h1>Banco de Dados com PDO</h1>
        </header>

        <main>

        <!--Menu de opções do sistema-->
        <ul>
            <li><a href="Atualizar.php">Atualizar dados</a></li>
            <li><a href="index.html">Inicio</a></li>
            <li><a href="Inserir.php">Inserir dados</a></li>
            <li><a href="Selecionar.php">Pesquisar dados</a></li>
        </ul>

        </main>

        <section>


            <?php

                /*Captura do valor passado pelo o usuário */
                $id = $_GET['id'] ?? 0;//valor padrão caso o usuário não informe nenhum valor
            
            
            ?>

            <!--Criação do formulário-->
            <!--O formulário ira fazer referencia a variavel SERVER, que ira mandar as informações para as variáveis em php.O metodo será get, pois queremos pegar a informação-->
            <form action="<?php  $_SERVER=['PHP_SELF']?>" method="get">
            
            <!--Legenda do  formulário-->
            <label for="id">Informe o id do veiculo que será excluido</label> 
            
            <!--campo para inserção de dados: não possuem autocomplete e não podem ser vázios-->
            <input type="number" name="id" id="idid" autocomplete="off" required>

            <!--Criação do botão de exclusão de dados-->
            <input type="submit" value="Apagar informações">
        
           </form>

        </section>

        <section>
            <?php
            
            /*Inclusão do arquivo que contem os metodos para manipular o banco de dados */
                include 'BancoDeDados.php';

                /*Instanciação do banco de dados */
                $banco = new BancoDeDados();
                
                /*chamada do Metodo apagar que irá receber como parametro o id passado pelo usuário*/
                $banco->apagar($id);

                /*Mensagem que indica o ultimo id apagado */
                echo "<p> Dados apagados até o momento: $id</p>";

                
            
            ?>
        </section>
    </body>

</html>
