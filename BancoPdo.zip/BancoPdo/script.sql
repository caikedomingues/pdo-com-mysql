


create database bancopdo;

use bancopdo;


create table veiculos(

id int auto_increment,
tipo enum('Moto','moto','MOTO', 'carro','Carro','CARRO', 'caminhão', 'Caminhão', 'CAMINHÃO'),
modelo text,
/*Sugestão de melhoria, deixar a placa como unique*/
placa varchar(4),

primary key(id)


)default charset = utf8;

delete from veiculos where id='26';

delete from veiculos where id='23';

delete from veiculos where id ='28';
delete from veiculos where id ='29';
delete from veiculos where id ='30';
delete from veiculos where id ='31';
delete from veiculos where id ='32';
delete from veiculos where id ='33';
delete from veiculos where id = '37';
delete from veiculos where id = '42';
delete from veiculos where id = '43';
delete from veiculos where id = '44';
delete from veiculos where id = '45';
delete from veiculos where id = '46';
delete from veiculos where id = '47';
delete from veiculos where id = '48';
delete from veiculos where id = '50';
delete from veiculos where id = '51';
delete from veiculos where id = '52';
delete from veiculos where id = '53';
delete from veiculos where id = '54';
delete from veiculos where id = '55';
delete from veiculos where id = '56';
delete from veiculos where id = '57';
delete from veiculos where id = '58';
delete from veiculos where id = '59';
delete from veiculos where id = '60';
delete from veiculos where id = '61';



/*Vamos agora alterar a tabela e adicionar a coluna datacriacao que ira receber o horário que o veiculo foi cadastrado*/

alter table veiculos
add column datacriacao datetime default now() not null;

/*Vamos também adicionar mais uma coluna que ira conter a data e o horário que o objeto foi atualizado*/
alter table veiculos
add column atualizacao datetime default now() on update now() not null ;

select * from veiculos;