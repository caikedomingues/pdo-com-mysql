



<?php

    

    /*A classe banco de dados ira conter todos os metodos necessários  para manipular o banco de dados mysql*/
    class BancoDeDados{

        /*O metodo conectar ira ter a variável de conexão com a instanciação 
        da classe pdo. */
        public function conectar(){

            /*Dentro do metodo, vamos criar um bloco try e catch que tera dentro dele a conexão
            com o banco de dados */
            try{
                
                /*A variável con ira conter a instanciação e o link para conexao */
                /*O link deve conter o comando padrão mysql:host=endereço do servidor, a porta do
                mysql, dbname=nome do banco de dados, usuario, senha. */
                $con = new PDO ('mysql:host=localhost; port=3306;dbname=bancopdo','root','');

                /*Retorno da conexão*/
                return $con;

            }catch(PDOException $erro){

                /*Exception que será lançada em casos de erro*/
                echo "</p> não foi possivel se conectar ao banco de dados: ".$erro.getMessage()."</p>";

                /*Em caso de erros, vamos retornar o valor null */
                return null;
            }

        }


        /*A função inserir tera como objetivo inserir dados no banco de dados.
            A função tera como parametro strings que irão conter os valores que serão inseridos no banco.
        */
        public function inserir(string $tipo = null, string $modelo = null, string $placa = null){

           try{

                /*Dentro do bloco try, vamos chamar o metodo de conexão */
               $conexao = $this->conectar();

               /*Após chamar o método, vamos atribuir a variável $resultado o metodo de conexao que ira chamar o metodo prepare que ira conter como parametro o comando sql para inserção */
               $resultado = $conexao->prepare("INSERT INTO veiculos(tipo, modelo, placa) VALUES(:tipo, :modelo, :placa)");
               
               /*Após preparar todos os metodos, vamos chamar o bindParam que ira receber como parametro a referencia do values e a variável que contem o valor que será inserido no banco de dados */

               $resultado->bindParam(':tipo', $tipo);

               $resultado->bindParam(':modelo',$modelo);

               $resultado->bindParam(':placa',$placa);

               /*Pra finalizar vamos executar as ações com o metodo execute */
               $resultado->execute();


           }catch(PDOException $erro){

                /*Exception que será lançada caso de erro na inserção */
                echo "</p> não foi possivel inserir os dados: ".$erro->getMessage()."</p>";
           }

            
        }


        /*A função atualizar terá como objetivo modificar os dados cadastrados no banco de dados. */
        /*A fnção tera como parametro um inteiro int e 3 parametros do tipo string */
        public function atualizar(int $id, string $tipo, string $modelo, string $placa){

            /*Dentro do método vamos criar os blocos try e catch que conteráo os blocos que realizaram a tarefa */
            try{
                /*Para iniciar o processo, temos que chamar o metodo conectar para se conectar ao banco de dados e realizar a tarefa */
               $conexao = $this->conectar();

               /*Após a conexão, vamos criar variáveos que irão receber a conexao e o metodo query que tem como parametro os comandos em sql */
               $resultadoTipo = $conexao->query("UPDATE veiculos SET tipo='$tipo' WHERE id=$id");

              $resultadoModelo = $conexao->query("UPDATE veiculos set modelo = '$modelo' WHERE id=$id");

              $resultadoPlaca = $conexao->query("UPDATE veiculos set placa = '$placa' WHERE id=$id");


            }catch(PDOException $erro){

                /*No catch vamos lançar a função PDOException, para lançar uma mensagem de erro ao usuário */
                echo "<p> Não foi possivel atualizar os dados: $erro</p>";
            }
        }

        
        /*A função apagar terá como objetivo excluir dados do banco de dados.*/
        /*A função terá como parametro um inteiro que representara o id*/
        public function apagar(int $id){
            
            /*Dentro do metodo teremos os blocos de try e catch */
            try{

                /*Dentro do try, vamos chamar o metodo de conexao para se conectar ao banco */
                $conexao = $this->conectar();

                /*Após a conexão, vamos atribuir a variável resultado a conexao e o metodo query com o comando sql*/
                $resultado = $conexao->query("DELETE FROM veiculos where id = '$id'");

                

            }catch(PDOException $erro){

                /*Exceção que será lançada em casos de erros */
                echo "<p> Não foi possivel deletar o veiculo $erro</p>";
            }

        }


        /*A função selecionar terá como objetivo mostrar os dados cadastrados no banco de dados. A função terá como parametro um inteiro que representa o id*/
        public function selecionar(int $id ){

            /*Dentro do metodo teremos um bloco try e catch */
            try{

                /*Dentro do try, vamos chamar o metodo conectar para realizar a conexão com o banco de dados. */
                $conexao = $this->conectar();

                /*Após a conexão, vamos atribuir a variável resultado a conexão do banco e o metodo query com o comando sql  */
                $resultado = $conexao->query("SELECT * FROM veiculos WHERE id=$id");

                /*Após pegar os dados no banco precisamos imprimi-los na tela através do foreach */
                foreach($resultado as $valores){

                    /*Para especificar a informação devemos passar o indice da coluna que contém o dado */
                    echo "<p>id: ".$valores[0]."</p>";
                    echo "<p>tipo: ".$valores[1]."</p>";
                    echo "<p>modelo: ".$valores[2]."</p>";
                    echo "<p>placa: ".$valores[3]."</p>";
                    echo "<p>data de criação: ".$valores[4]."</p>";
                    echo "<p>data de atualização: ".$valores[5]."</p>";

                }



            }catch(PDOException $erro){

                /*Exceção que será lançada em casos de erro */
                "<p> não foi possivel pesquisar os dados: $erro</p>";
            }
        }
    }


   

?>